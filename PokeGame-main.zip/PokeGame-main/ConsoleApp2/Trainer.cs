﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PokeGame
{
    internal class Trainer
    {
        // Detta är en statisk metod. Statiska metoder anropas via typen och inte via objekt.
        public static void Greeting() 
        {
            Console.WriteLine("Hi!");
        }
    }
}
