﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PokeGame
{
    public enum Attacks
    {
        QuickAttack,
        Scratch,
        Ember,
        ThunderBolt
    }
}
